export interface Barang {
    id: string;
    title: string;
    imageUrl: string;
    harga: number;
    stock: number;
}
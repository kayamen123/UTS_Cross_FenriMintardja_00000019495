import { Component, OnInit } from '@angular/core';
import { Barang } from './barang.model';
import { BarangService } from './barang.service';

@Component({
  selector: 'app-barang',
  templateUrl: './barang.page.html',
  styleUrls: ['./barang.page.scss'],
})
export class BarangPage implements OnInit {

  barangs: Barang[];
  constructor(private barangsService: BarangService ) { }

  ngOnInit() {
    
  }
  
  ionViewWillEnter(){
    this.barangs = this.barangsService.getAllBarangs();
 }

}

import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Barang } from './barang.model';

@Injectable({
  providedIn: 'root'
})
export class BarangService {
  private barangs: Barang[] = [
    {
      id: 'b1',
      title: 'AMD',
      imageUrl: 'https://c1.neweggimages.com/ProductImageCompressAll1280/19-113-569-V10.jpg',
      harga: 50000,
      stock: 20
    },
    {
      id: 'b2',
      title: 'Intel',
      imageUrl: 'https://c1.neweggimages.com/ProductImageCompressAll1280/19-113-569-V10.jpg',
      harga: 45000,
      stock: 15
    },
    {
      id: 'b3',
      title: 'Nvidia',
      imageUrl: 'https://c1.neweggimages.com/ProductImageCompressAll1280/19-113-569-V10.jpg',
      harga: 3000,
      stock: 25
    }
  ];

  constructor() { }

  getAllBarangs() { 
    return [...this.barangs];
  }

  getBarang(barangId: string) {
    return{...this.barangs.find( barang => {
      return barang.id === barangId;
    })};
  }

  deleteBarang(barangId: string){
    this.barangs = this.barangs.filter(barang => {
      return barang.id !== barangId;
    });
  }

  addBarang(form: FormGroup) {
    this.barangs.push({
      id: "b"+this.barangs.length + 1 + "",
      title: form.value.title,
      imageUrl: form.value.imageUrl,
      harga: form.value.harga,
      stock: form.value.stock,
    });
  }

  editBarang(form: FormGroup, id: string) {
    let tempArr = this.barangs.map((barang) => {
      if (barang.id === id) {
        return {
          id: id,
          title: form.value.title,
          imageUrl: form.value.imageUrl,
          harga: form.value.harga,
          stock: form.value.stock,
        };
      }
      return barang;
    });
    this.barangs = [...tempArr];
  }

}
